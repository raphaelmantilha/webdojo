//import consultancyData from '../fixtures/consultancy.json'
import { personal, company } from '../fixtures/consultancy.json'

describe('Formulário de Consultoria', () => {

    before(() => {
        cy.log('Isso acontece antes de todos os testes uma única vez')
    })
    beforeEach(() => {
        cy.login();
        cy.goTo('Formulários', 'Consultoria')

        //cy.fixture('consultancy').as('consultancyData')
    })

    afterEach(() => {
        cy.log('Isso acontece depois de cada teste')
    })

    after(() => {
        cy.log('Isso acontece depois de todos os testes uma única vez')
    })

    it('Deve solicitar consultoria individual', () => {

        //const consultancyForm = consultancyData.personal

        cy.get('input[placeholder="Digite seu nome completo"]').type(personal.name)
        cy.get('input[placeholder="Digite seu email"]').type(personal.email)

        cy.get('input[placeholder="(00) 00000-0000"]')
            .type(personal.phone)
        //.should('have.value', '(19) 99999-8888')

        // //label[text()="Tipo de Consultoria"]/..//select    
        cy.contains('label', 'Tipo de Consultoria')
            .parent()
            .find('select')
            .select(personal.consultancyType)

        // //span[text()="Pessoa Física"]/..//input

        cy.contains('span', 'Pessoa Física')
            .parent()
            .find('input')
            .click() //ou check()
            .should('be.checked')

        cy.contains('span', 'Pessoa Jurídica')
            .parent()
            .find('input')
            .should('be.not.checked')

        cy.contains('label', 'CPF')
            .parent()
            .find('input')
            .type(personal.document)
        //.should('have.value', '817.194.500-72')

        const discoveryChannels = [
            'Instagram',
            'LinkedIn',
            'Udemy',
            'YouTube',
            'Indicação de Amigo'
        ]

        personal.discoveryChannels.forEach((channel) => {
            cy.contains('span', channel)
                .parent()
                .find('input')
                .check() //ou click()
                .should('be.checked')
        })

        cy.get('input[type="file"]')
            .selectFile(personal.file, { force: true })
        //pdf obtido em lorempdf.com

        cy.get('textarea[placeholder="Descreva mais detalhes sobre sua necessidade"]')
            .type(personal.description)
        //texto obtido em loremipsum.io

        cy.get('input[placeholder="Digite uma tecnologia e pressione Enter"]')
            .type('Cypress')
            .type('{enter}')

        personal.techs.forEach((tech) => {
            cy.get('input[placeholder="Digite uma tecnologia e pressione Enter"]')
                .type(tech)
                .type('{enter}')

            // cy.contains('span', tech)
            //     .should('be.visible') Não é uma boa estratégia porque qualquer outra span com texto "Cypress" seria validado aqui

            cy.contains('label', 'Tecnologias')
                .parent()
                .contains('span', tech)
                .should('be.visible')
        })

        if (personal.terms === true) {
            cy.contains('label', 'termos de uso')
                .find('input')
                .check()
        }

        cy.contains('button', 'Enviar formulário')
            .click()

        cy.get('.modal', { timeout: 7000 })
            .should('be.visible')
            .find('.modal-content')
            .should('be.visible')
            .and('have.text', 'Sua solicitação de consultoria foi enviada com sucesso! Em breve, nossa equipe entrará em contato através do email fornecido.')
    })

    it('Deve solicitar consultoria in company', () => {

        //const consultancyForm = consultancyData.company

        cy.get('input[placeholder="Digite seu nome completo"]').type(company.name)
        cy.get('input[placeholder="Digite seu email"]').type(company.email)

        cy.get('input[placeholder="(00) 00000-0000"]')
            .type(company.phone)
        //.should('have.value', '(19) 99999-8888')

        // //label[text()="Tipo de Consultoria"]/..//select    
        cy.contains('label', 'Tipo de Consultoria')
            .parent()
            .find('select')
            .select(company.consultancyType)

        cy.contains('span', 'Pessoa Jurídica')
            .parent()
            .find('input')
            .click() //ou check()
            .should('be.checked')

        cy.contains('span', 'Pessoa Física')
            .parent()
            .find('input')
            .should('be.not.checked')

        cy.contains('label', 'CNPJ')
            .parent()
            .find('input')
            .type(company.document)
        //.should('have.value', '817.194.500-72')

        const discoveryChannels = [
            'Instagram',
            'LinkedIn',
            'Udemy',
            'YouTube',
            'Indicação de Amigo'
        ]

        company.discoveryChannels.forEach((channel) => {
            cy.contains('span', channel)
                .parent()
                .find('input')
                .check() //ou click()
                .should('be.checked')
        })

        cy.get('input[type="file"]')
            .selectFile(company.file, { force: true })
        //pdf obtido em lorempdf.com

        cy.get('textarea[placeholder="Descreva mais detalhes sobre sua necessidade"]')
            .type(company.description)
        //texto obtido em loremipsum.io

        cy.get('input[placeholder="Digite uma tecnologia e pressione Enter"]')
            .type('Cypress')
            .type('{enter}')

        company.techs.forEach((tech) => {
            cy.get('input[placeholder="Digite uma tecnologia e pressione Enter"]')
                .type(tech)
                .type('{enter}')

            // cy.contains('span', tech)
            //     .should('be.visible') Não é uma boa estratégia porque qualquer outra span com texto "Cypress" seria validado aqui

            cy.contains('label', 'Tecnologias')
                .parent()
                .contains('span', tech)
                .should('be.visible')
        })

        if (company.terms === true) {
            cy.contains('label', 'termos de uso')
                .find('input')
                .check()
        }

        cy.contains('button', 'Enviar formulário')
            .click()

        cy.get('.modal', { timeout: 7000 })
            .should('be.visible')
            .find('.modal-content')
            .should('be.visible')
            .and('have.text', 'Sua solicitação de consultoria foi enviada com sucesso! Em breve, nossa equipe entrará em contato através do email fornecido.')
    })

    it('Deve verificar os campos obrigatórios', () => {
        cy.contains('button', 'Enviar formulário')
            .click()

        //label[text()="Nome Completo *"]/..//p
        cy.contains('label', 'Nome Completo')
            .parent()
            .find('p')
            .should('be.visible')
            .should('have.text', 'Campo obrigatório')
            .and('have.class', 'text-red-400')
            .and('have.css', 'color', 'rgb(248, 113, 113)')

        //label[text()="Email *"]/..//p
        cy.contains('label', 'Email')
            .parent()
            .find('p')
            .should('be.visible')
            .should('have.text', 'Campo obrigatório')
            .and('have.class', 'text-red-400')
            .and('have.css', 'color', 'rgb(248, 113, 113)')

        cy.contains('label', 'termos de uso')
            .parent()
            .find('p')
            .should('be.visible')
            .should('have.text', 'Você precisa aceitar os termos de uso')
            .and('have.class', 'text-red-400')
            .and('have.css', 'color', 'rgb(248, 113, 113)')
    })
})